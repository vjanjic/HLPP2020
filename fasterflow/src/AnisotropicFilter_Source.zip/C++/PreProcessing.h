#pragma once

#ifndef _PREPROCESSING            
#define _PREPROCESSING	
#endif	

#include "cv.h"
#include "highgui.h"

//generate Pseudodata
void generatePseudoData(cv::Mat src, int width, int height);


